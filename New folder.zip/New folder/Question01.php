<?php

class Math{
    
    var $number1;
    var $number2;
    var $total;

    public function input_two_no($number1,$number2){
        $this->number1=$number1;
        $this->number2=$number2;
    }

    public function sum(){
        $this->total = $this->number1 + $this->number2;
    }

    public function output_the_sum(){
        echo $this->number1 . "+" . $this->number2 ."=". $this->total;
    }

}

$numbers = new Math;
$numbers->input_two_no(3,15);
$numbers->sum();
$numbers->output_the_sum();

echo "<br>";

$numbers = new Math;
$numbers->input_two_no(18,5);
$numbers->sum();
$numbers->output_the_sum();


?>