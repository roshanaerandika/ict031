<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<?php 



public class Student{
	public $stuName;
	public $regName;


	public function __construct($stuName , $regName){
		$this -> stuName = $stuName;
		$this -> regName = $regName;
	}

	public function display(){
		echo "Student name {$this->stuName} and reg number {$this->regNum}";
	}
}


public class Subject extends Student{

	function stu(){
		echo "Subject";
	}

}


$obj1 = new Subject("Nimal","067");
$obj1 -> display();


 ?>


</body>
</html>